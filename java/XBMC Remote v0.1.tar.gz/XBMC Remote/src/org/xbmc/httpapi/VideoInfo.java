/*
 *      Copyright (C) 2005-2009 Team XBMC
 *      http://xbmc.org
 *
 *  This Program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2, or (at your option)
 *  any later version.
 *
 *  This Program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with XBMC Remote; see the file license.  If not, write to
 *  the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.
 *  http://www.gnu.org/copyleft/gpl.html
 *
 */

package org.xbmc.httpapi;

public class VideoInfo {
/*	private static final int VIDEOPLAYER_TITLE             = 250;
	private static final int VIDEOPLAYER_GENRE             = 251;
	private static final int VIDEOPLAYER_DIRECTOR          = 252;
	private static final int VIDEOPLAYER_YEAR              = 253;
	private static final int VIDEOPLAYER_COVER             = 258;
	private static final int VIDEOPLAYER_USING_OVERLAYS	   = 259;
	private static final int VIDEOPLAYER_ISFULLSCREEN      = 260;
	private static final int VIDEOPLAYER_HASMENU           = 261;
	private static final int VIDEOPLAYER_PLAYLISTLEN       = 262;
	private static final int VIDEOPLAYER_PLAYLISTPOS       = 263;
	private static final int VIDEOPLAYER_EVENT             = 264;
	private static final int VIDEOPLAYER_ORIGINALTITLE     = 265;
	private static final int VIDEOPLAYER_PLOT              = 266;
	private static final int VIDEOPLAYER_PLOT_OUTLINE      = 267;
	private static final int VIDEOPLAYER_EPISODE           = 268;
	private static final int VIDEOPLAYER_SEASON            = 269;
	private static final int VIDEOPLAYER_RATING            = 270;
	private static final int VIDEOPLAYER_TVSHOW            = 271;
	private static final int VIDEOPLAYER_PREMIERED         = 272;
	private static final int VIDEOPLAYER_CONTENT           = 273;
	private static final int VIDEOPLAYER_STUDIO            = 274;
	private static final int VIDEOPLAYER_MPAA              = 275;
	private static final int VIDEOPLAYER_CAST              = 276;
	private static final int VIDEOPLAYER_CAST_AND_ROLE     = 277;
	private static final int VIDEOPLAYER_ARTIST            = 278;
	private static final int VIDEOPLAYER_ALBUM             = 279;
	private static final int VIDEOPLAYER_WRITER            = 280;
	private static final int VIDEOPLAYER_TAGLINE           = 281;
	private static final int VIDEOPLAYER_HAS_INFO          = 282;
	private static final int VIDEOPLAYER_TOP250            = 283;
	private static final int VIDEOPLAYER_RATING_AND_VOTES  = 284;
	private static final int VIDEOPLAYER_TRAILER           = 285;
	private static final int VIDEOPLAYER_VIDEO_CODEC       = 286;
	private static final int VIDEOPLAYER_VIDEO_RESOLUTION  = 287;
	private static final int VIDEOPLAYER_AUDIO_CODEC       = 288;
	private static final int VIDEOPLAYER_AUDIO_CHANNELS    = 289;*/
}
